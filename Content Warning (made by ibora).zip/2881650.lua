-- ============================================
--  Credits: K3rnelPan1c (KernelOS / !K3rnalyze)
--  Discord: https://discord.gg/k3rnalyze
--  Website: https://kernelos.org/games
-- ============================================

addappid(2881650)
addappid(2881651,0,"def8422fa7589f4d65aa2cbbb21d623f10e3ad941e695558651289920c89c1d9")
