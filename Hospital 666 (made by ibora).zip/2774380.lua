-- ============================================
--  Credits: K3rnelPan1c (KernelOS / !K3rnalyze)
--  Discord: https://discord.gg/k3rnalyze
--  Website: https://kernelos.org/games
-- ============================================

addappid(2774380)
addappid(2774381,0,"375790a30273b5f285bca3d552eb92c9442933076e3c858c9d58026f98bfe360")
