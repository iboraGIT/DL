-- ============================================
--  Credits: K3rnelPan1c (KernelOS / !K3rnalyze)
--  Discord: https://discord.gg/k3rnalyze
--  Website: https://kernelos.org/games
-- ============================================

addappid(1302240)
addappid(1302241,0,"1f0abf461681b647baf3263a992ea65516c85019d3015e79620b7136afb158dd")
addappid(2438400)
